﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class PlayerMove : MonoBehaviour
{
    Rigidbody2D rb, targetRb;
    private float speed = 6f;
    private float jump = 300;
    private float jumpPow;
    private Animator animator;
    AnimatorStateInfo animStateInfo;
    bool ground;
    private float WS;

    bool groundFlag;

    bool jumpBotton;
    float flameCount;

    private float oldJump = 0;
    private float g = (-9.81f);
    private int moveFlag = 0;//左右への移動できるかどうか　0:移動可能　1:右移動不可　2:左移動不可　3:左右移動不可

    private RaycastHit2D[] l_Hit = { new RaycastHit2D(), new RaycastHit2D(), new RaycastHit2D() };
    private RaycastHit2D[] d_Hit = { new RaycastHit2D(), new RaycastHit2D(), new RaycastHit2D() };
    private RaycastHit2D[] r_Hit = { new RaycastHit2D(), new RaycastHit2D(), new RaycastHit2D() };
    Vector3 tmpPos;
    private Vector2[] rayDir;
    private Ray[] ray;

    public CheckPointData checkPointData;

    private bool DeathFlag;

    public enum Dir
    {
        LEFT,  // 左
        RIGHT, // 右
        NON    // 方向なっしー！！！ヒャッハーーー！！！！
    }

    //入力方向
    private Dir inputDir;
    //プレイヤーの向いてる向き
    private Dir drawDir;
    //前フレームで向いてる方向
    private Dir oldDir;

    private LoadSceneManager loadSceneManager;
    private Animator deathAnimator;//死亡時のやーつ

    //Use this for initialization
    void Start()
    {
        inputDir = Dir.NON;
        drawDir = Dir.RIGHT;
        groundFlag = true;
        rayDir = new Vector2[] { Vector2.right, Vector2.down, Vector2.left };
        rb = GetComponent<Rigidbody2D>();

        animator = GetComponent<Animator>();

        transform.position = checkPointData.startPosition;
        DeathFlag = false;
        loadSceneManager = GameObject.Find("Management").GetComponent<LoadSceneManager>();
        deathAnimator = GameObject.Find("DeathCanvas").GetComponent<Animator>();

        deathAnimator.SetInteger("FadeFlag", 0);
        deathAnimator.SetBool("ReStartFlag", false);
    }

    //Update is called once per frame
    void FixedUpdate()
    {
        if (DeathFlag == false)
        {
            //--空中にいるときに壁にくっつかないようにする処理
            tmpPos = new Vector3(transform.position.x, transform.position.y, transform.position.z);//Rayに使うプレイヤーの中心の座標
            RayCreate();

            GroundCheck();

            MoveCheck();

            //左右どちらにも移動できない場合以外のみこの処理の中に入る
            if (moveFlag != 3)
            {
                //右移動だけできなくする
                if ((Input.GetAxis("Horizontal") > 0) && (moveFlag == 1))
                {
                    WS = (Input.GetAxis("Horizontal") > 0 ? 0 : Input.GetAxis("Horizontal")) * speed;
                }
                //左移動だけできなくする
                else if ((Input.GetAxis("Horizontal") < 0) && (moveFlag == 2))
                {
                    WS = (Input.GetAxis("Horizontal") < 0 ? 0 : Input.GetAxis("Horizontal")) * speed;
                }
                //移動制限がないとき
                else
                {
                    WS = Input.GetAxis("Horizontal") * speed;
                }
            }

            //--左右どちらに向いているか
            //右に向いている場合
            if (Input.GetAxis("Horizontal") > 0)
            {
                inputDir = Dir.RIGHT;
            }
            //左に向いている場合
            else if (Input.GetAxis("Horizontal") < 0)
            {
                inputDir = Dir.LEFT;
            }
            else
            {
                inputDir = Dir.NON;
            }

            if (inputDir == Dir.NON)
            {
                oldDir = drawDir;
                drawDir = oldDir;
            }
            else
            {
                drawDir = inputDir;
            }

            animStateInfo = animator.GetCurrentAnimatorStateInfo(0); // animatorのStateを取得

            //右移動
            if (inputDir == Dir.RIGHT)
            {
                transform.rotation = Quaternion.Euler(0, 180, 0);
                //アニメーション
                animator.SetBool("Running", true);
            }
            //左移動
            else if (inputDir == Dir.LEFT)
            {
                transform.rotation = Quaternion.Euler(0, 0, 0);
                animator.SetBool("Running", true);
            }

            //何もキーを押していない時はアニメーションをオフにする
            else
            {
                animator.SetBool("Running", false);
            }

            //--ジャンプ処理
            //ジャンプボタン(スペースキー)が押されていない場合
            if ((jumpBotton == false) && (JumpAnimatorCheck()))
            {
                //スペースキーでジャンプする
                if (Input.GetButton("Jump"))
                {
                    animator.SetBool("Jumping", true);
                    jumpPow = (jump - oldJump) * Vector2.up.y;
                    rb.AddForce(new Vector3(0, jumpPow, 0));
                    //入力(ボタンを押されてる)されてる時間
                    flameCount = flameCount + 1 * Time.deltaTime;
                    oldJump = jump - (jump / 10);

                }

                if (Input.GetButtonUp("Jump"))
                {
                    jumpBotton = true;
                }
                else if (flameCount >= 0.30f)
                {
                    jumpBotton = true;
                }
                else { }

            }

            //地面についているかどうかによって処理を変える
            if (groundFlag == false)
            {
                //ついていない場合は下に落ちる処理も加える
                rb.AddForce(new Vector3(speed * (WS - rb.velocity.x), g, 0));
            }
            else
            {
                rb.AddForce(new Vector3(speed * (WS - rb.velocity.x), 0, 0));
            }
        }

        if (Input.GetKeyDown(KeyCode.R) && loadSceneManager.loadFlag == false)
        {
            deathAnimator.SetBool("ReStartFlag", true);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if ((collision.gameObject.tag == "Death") || (collision.gameObject.tag == "Enemy"))
        {
            if (DeathFlag == false && loadSceneManager.loadFlag == false)
            {
                animator.SetBool("DeathFlag", true);
                deathAnimator.SetInteger("FadeFlag", 1);
                //loadSceneManager.FadeAndLoadScene(SceneManager.GetActiveScene().name);
                DeathFlag = true;
            }
        }
    }

    private void RayCreate()
    {

        moveFlag = 0;


        //上以外の三方向に飛ばすRayを作る(左右は三つに分ける)
        ray = new Ray[]{
            new Ray(new Vector3 (tmpPos.x,tmpPos.y + 0.7f,tmpPos.z), rayDir[0]),
            new Ray(tmpPos, rayDir[0]),
            new Ray(new Vector3 (tmpPos.x,tmpPos.y - 0.7f,tmpPos.z), rayDir[0]),//2

            new Ray(new Vector3 (tmpPos.x + 0.19f,tmpPos.y-0.8f,tmpPos.z), rayDir[1]),
            new Ray(new Vector3 (tmpPos.x,tmpPos.y-0.8f,tmpPos.z), rayDir[1]),
            new Ray(new Vector3 (tmpPos.x - 0.19f,tmpPos.y-0.8f,tmpPos.z), rayDir[1]),//5

            new Ray(new Vector3 (tmpPos.x,tmpPos.y + 0.7f,tmpPos.z), rayDir[2]),
            new Ray(tmpPos, rayDir[2]),
            new Ray(new Vector3 (tmpPos.x,tmpPos.y - 0.7f,tmpPos.z), rayDir[2]) };//8

        float tmpRay = 0.24f;
        float tmpRay2 = 0.03f;
        int layerMask = LayerMask.GetMask(new string[] { LayerMask.LayerToName(8) });

        r_Hit[0] = Physics2D.Raycast(ray[0].origin, ray[0].direction, tmpRay, layerMask);    //右のRayその1(大体目のあたり)
        r_Hit[1] = Physics2D.Raycast(ray[1].origin, ray[1].direction, tmpRay, layerMask);    //右のRayその2(体の真ん中から右)
        r_Hit[2] = Physics2D.Raycast(ray[2].origin, ray[2].direction, tmpRay, layerMask);    //右のRayその3(大体太もものあたり)

        d_Hit[0] = Physics2D.Raycast(ray[3].origin, ray[3].direction, tmpRay2, layerMask);       //下のRay(真ん中から下)
        d_Hit[1] = Physics2D.Raycast(ray[4].origin, ray[4].direction, tmpRay2, layerMask);       //下のRay(真ん中から下)
        d_Hit[2] = Physics2D.Raycast(ray[5].origin, ray[5].direction, tmpRay2, layerMask);       //下のRay(真ん中から下)

        l_Hit[0] = Physics2D.Raycast(ray[6].origin, ray[6].direction, tmpRay, layerMask);    //左のRayその1(大体目のあたり)
        l_Hit[1] = Physics2D.Raycast(ray[7].origin, ray[7].direction, tmpRay, layerMask);    //左のRayその2(体の真ん中から右)
        l_Hit[2] = Physics2D.Raycast(ray[8].origin, ray[8].direction, tmpRay, layerMask);    //左のRayその3(大体太もものあたり)
    }

    private void GroundCheck()
    {
        if (GroundRayCheck())
        {
            groundFlag = true;
            animator.SetBool("Jumping", false);
            animator.SetBool("FallFlag", false);
            jumpPow = 0.0f;

            jumpBotton = false;
            flameCount = 0;
            oldJump = 0f;
        }
        else
        {
            groundFlag = false;
            if (jumpBotton == true || flameCount <= 0.0f)
            {
                animator.SetBool("Jumping", true);
                animator.SetBool("FallFlag", true);
                jumpBotton = true;
            }
        }
    }

    private void MoveCheck()
    {
        //下に飛ばしているRayが当たってない時(空中にいる場合)
        //if (GroundRayCheck() == false)
        //{
        //三つのうちどれかでも壁を探知すれば右に移動するのを禁止
        if (r_Hit[0].collider != null || r_Hit[1].collider != null || r_Hit[2].collider != null)
        {
            moveFlag += 1;
        }

        //三つのうちどれかでも壁を探知すれば左に移動するのを禁止
        if (l_Hit[0].collider != null || l_Hit[1].collider != null || l_Hit[2].collider != null)
        {
            moveFlag += 2;
        }
        // }
    }

    public Dir GetPlayerDir()
    {
        return drawDir;
    }

    public void SetFollFlag()
    {
        animator.SetBool("FallFlag", true);
    }

    public bool GroundRayCheck()
    {
        if (d_Hit[0].collider == null && d_Hit[1].collider == null && d_Hit[2].collider == null)
        {
            return false;
        }
        return true;
    }
    public bool JumpAnimatorCheck()
    {
        if (animStateInfo.IsName("Idol")
        || animStateInfo.IsName("Jump")
        || animStateInfo.IsName("Move"))
        {
            return true;
        }
        return false;
    }
}