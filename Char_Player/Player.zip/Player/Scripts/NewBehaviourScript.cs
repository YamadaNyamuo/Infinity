﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour {

    public Explodable explodable;

    // Use this for initialization
    void Start () {
		
	}

   

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            explodable.explode();
            
        }
    }
}
