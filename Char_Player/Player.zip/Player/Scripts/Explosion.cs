﻿using UnityEngine;
using System.Collections;

public class Explosion : MonoBehaviour {
    public float coefficient;   // 空気抵抗係数
    public float speed;         // 爆風の速さ

    void OnTriggerStay2D(Collider2D col)
    {
        if(col.transform.tag=="DeathPlayer")
        {
            if (col.GetComponent<Rigidbody2D>() == null)
            {
                return;
            }

            // 風速計算
            var velocity = (col.transform.position - transform.position).normalized * speed;

            // 風力与える
            col.GetComponent<Rigidbody2D>().AddForce(coefficient * velocity);
        }
        
    } 
}
